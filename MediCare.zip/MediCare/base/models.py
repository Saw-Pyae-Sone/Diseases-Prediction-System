from django.db import models
# from django.contrib.auth.models import AbstractUser, Group, Permission

# Create your models here.
    
class Patient(models.Model):
    Patient_ID = models.AutoField(primary_key = True)
    Patient_Name = models.CharField(max_length=200)
    Patient_Email = models.CharField(max_length=255)
    Patient_Password = models.CharField(max_length=255)
    Patient_Address = models.CharField(max_length=255)
    Patient_Family_Medical_History = models.ImageField(upload_to='../static/Image')

    def __str__(self):
        return self.Patient_Name

class Admin(models.Model):
    Admin_ID = models.AutoField(primary_key = True)
    Admin_Name = models.CharField(max_length=200)
    Admin_Email = models.CharField(max_length=255)
    Admin_Password = models.CharField(max_length=200, default='admin123')
    is_active = models.BooleanField(default=True)
    # groups = models.ManyToManyField(Group, related_name='admin_groups')
    # user_permissions = models.ManyToManyField(Permission, related_name='admin_user_permissions')

    def __str__(self):
        return self.Admin_Name

class Doctor(models.Model):
    Doctor_ID = models.AutoField(primary_key = True)
    Doctor_Name = models.CharField(max_length=200)
    Doctor_Email = models.CharField(max_length=255)
    Doctor_Password = models.CharField(max_length=200)
    Doctor_Address = models.CharField(max_length=255)
    Doctor_Experience = models.CharField(max_length = 200, default = 0)
    Doctor_License = models.CharField(max_length = 200, default = 0)
    Doctor_Specialty = models.CharField(max_length = 255, default = 0)
    Doctor_Languages = models.CharField(max_length = 255, default = 0)
    Doctor_Image = models.ImageField(upload_to='cimg/', null=True, blank=True)
    # Doctor_Image = models.CharField(max_length = 255, default = 0)
    Admin_ID = models.ForeignKey(Admin, on_delete=models.CASCADE)

    def __str__(self):
        return self.Doctor_Name

class Feedback(models.Model):
    Feedback_ID = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=200)
    Message = models.TextField()
    Patient_ID = models.ForeignKey(Patient, on_delete=models.CASCADE)

    def __str__(self):
        return self.Title

class History(models.Model):
    History_Id = models.AutoField(primary_key=True)
    Patient_ID = models.ForeignKey(Patient, on_delete=models.CASCADE)
    Doctor_ID = models.ForeignKey(Doctor, on_delete=models.CASCADE)

    def __stf__(self):
        return self.History_Id

class Parkinsons(models.Model):
    Par_ID = models.AutoField(primary_key=True)
    MDVP_FO_Hz = models.FloatField()
    MDVP_Fhi_Hz = models.FloatField()
    MDVP_Flo_hz = models.FloatField()
    MDVP_Jitter_percentage = models.FloatField()
    MDVP_Jibber_Abs = models.FloatField()
    MDVP_RAP = models.FloatField()
    MDVP_PPQ = models.FloatField()
    Jitter_DDP = models.FloatField()
    MDVP_Shimmer = models.FloatField()
    MDVP_Shimmer_dB = models.FloatField()
    Shimmer_APQ3 = models.FloatField()
    Shimmer_APQ5 = models.FloatField()
    MDVP_APQ = models.FloatField()
    Shimmer_DDA = models.FloatField()
    NHR = models.FloatField()
    HNR = models.FloatField()
    RPDE = models.FloatField()
    DFA = models.FloatField()
    spread1 = models.FloatField()
    spread2 = models.FloatField()
    D2 = models.FloatField()
    PPE = models.FloatField()
    status = models.IntegerField()

    def __stf__(self):
        return self.status

class Diabetes(models.Model):
    Dia_ID = models.AutoField(primary_key=True)
    HighBP = models.FloatField()
    HighChol = models.FloatField()
    CholCheck = models.FloatField()
    BMI = models.FloatField()
    Smoker = models.FloatField()
    Stroke = models.FloatField()
    HeartDiseaseorAttack = models.FloatField()
    PhysActivity = models.FloatField()
    Fruits = models.FloatField()
    Veggies = models.FloatField()
    HvyAlcoholConsump = models.FloatField()
    AnyHealthcare = models.FloatField()
    NoDocbcCost = models.FloatField()
    GenHlth = models.FloatField()
    MentHlth = models.FloatField()
    PhysHlth = models.FloatField()
    DiffWalk = models.FloatField()
    Sex = models.FloatField()
    Age = models.IntegerField()
    Education = models.FloatField()
    Income = models.FloatField()

    def __stf__(self):
        return self.HeartDiseaseorAttack

class Heart_Disease(models.Model):
    HD_ID = models.AutoField(primary_key=True)
    age = models.IntegerField()
    sex = models.IntegerField()
    cp = models.IntegerField()
    trestbps = models.IntegerField()
    chol = models.IntegerField()
    fbs = models.IntegerField()
    restecg = models.IntegerField()
    thalach = models.IntegerField()
    exang = models.IntegerField()
    oldpeak = models.FloatField()
    slope = models.IntegerField()
    ca = models.IntegerField()
    thal = models.IntegerField()
    target = models.IntegerField()

    def __stf__(self):
        return self.target
    
class Patient_Symptoms(models.Model):
    PS_ID = models.AutoField(primary_key=True)
    Patient_ID = models.ForeignKey(Patient, on_delete=models.CASCADE)
    Par_ID = models.ForeignKey(Parkinsons, on_delete=models.CASCADE)
    Dia_ID = models.ForeignKey(Diabetes, on_delete=models.CASCADE)
    HD_ID = models.ForeignKey(Heart_Disease, on_delete=models.CASCADE)

    def __stf__(self):
        return self.PS_ID

class Symptoms(models.Model):
    S_ID = models.AutoField(primary_key=True)
    Par_ID = models.ForeignKey(Parkinsons, on_delete=models.CASCADE)
    Dia_ID = models.ForeignKey(Diabetes, on_delete=models.CASCADE)
    HD_ID = models.ForeignKey(Heart_Disease, on_delete=models.CASCADE)
    Admin_ID = models.ForeignKey(Admin, on_delete=models.CASCADE)
    History_ID = models.ForeignKey(History,on_delete=models.CASCADE)

    def __stf__(self):
        return self.S_ID



