# from django.contrib import admin
from django.urls import path, include
from .views import *

urlpatterns = [

    # path('admin/', include('customadmin.urls')),
    path('', custom_login, name='custom_login'),  # Corrected URL name
    path('dashboard/', dashboard, name='dashboard'),  # Corrected URL name
    path('login/', login, name='login'),  # Corrected URL name
    path('add_doctor/', add_doctor, name='add_doctor'),
    path('logout/', custom_logout, name='custom_logout'),
    path('update_doctor/', update_doctor, name='update_doctor'),
    path('delete_doctor/', delete_doctor, name='delete_doctor'),
]