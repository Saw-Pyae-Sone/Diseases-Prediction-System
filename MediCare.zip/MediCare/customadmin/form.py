# from django.forms import ModelForm
# from base.models import Doctor
# from django import forms

# class DoctorForm(ModelForm):
#     class Meta:
#         model = Doctor
#         fields = ['Doctor_Name', 'Doctor_Email', 'Doctor_Password', 'Doctor_Address', 'Doctor_Experience', 'Doctor_License', 'Doctor_Specialty', 'Doctor_Languages', 'Doctor_Image']
#         exclude = ['Admin_ID']

# def save(self, commit=True):
#     instance = super().save(commit=False)
#     doctor_image = self.cleaned_data.get('Doctor_Image')
#     instance.Doctor_Image = doctor_image.name if doctor_image else None
#     if commit:
#         instance.save()
#     return instance

from django import forms
from base.models import Doctor

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ['Doctor_Name', 'Doctor_Email', 'Doctor_Password', 'Doctor_Address', 'Doctor_Experience', 'Doctor_License', 'Doctor_Specialty', 'Doctor_Languages', 'Doctor_Image']
        exclude = ['Admin_ID']
        widgets = {
            'Doctor_Password': forms.PasswordInput(),
        }

    def save(self, commit=True):
        instance = super(DoctorForm, self).save(commit=False)
        doctor_image = self.cleaned_data.get('Doctor_Image')

        if doctor_image:
            instance.Doctor_Image = doctor_image.name
        else:
            if self.fields['Doctor_Image'].required:
                raise forms.ValidationError("Doctor Image is required.")
            else:
                instance.Doctor_Image = None
        
        if commit:
            instance


