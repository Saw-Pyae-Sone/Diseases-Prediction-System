# # views.py
# from django.shortcuts import render, redirect
# from django.contrib.auth import authenticate, login as auth_login
# from django.contrib import messages
# from customadmin.backend import AdminBackend
# from django.contrib.auth.decorators import login_required
# from django.contrib.auth import logout
# from .form import DoctorForm
# from base.models import Doctor
# from django.db import transaction

# def custom_login(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password = request.POST.get('password')
        
#         user = AdminBackend().authenticate(request, username=username, password=password)

#         if user is not None and hasattr(user, 'Admin_ID'):
#             # auth_login(request, user)
#             request.session['Admin_ID'] = user.Admin_ID

#             messages.success(request, f'Welcome, {username}!')
#             return redirect('dashboard') 
#         else:
#             messages.error(request, 'Invalid username or password.')

#     return render(request, 'C-admin/adlogin.html')

# @login_required(login_url='login')
# def custom_logout(request):
#     if 'Admin_ID' in request.session:
#         del request.session['Admin_ID']
    
#     logout(request)
#     messages.success(request, 'You have been successfully logged out.')
#     return redirect('Ad-login')

# @login_required(login_url='login')
# def add_doctor(request):
#     if request.method == 'POST':
#         form = DoctorForm(request.POST, request.FILES)
#         if form.is_valid():
#             admin_id = request.session.get('Admin_ID')
#             if admin_id is not None:
#                 with transaction.atomic():
#                     doctor = form.save(commit=False)
#                     doctor.Admin_ID_id = admin_id
#                     doctor.save()
#                 messages.success(request, 'Doctor created successfully.')
#                 return redirect('add_doctor')
#             else:
#                 messages.error(request, 'Admin ID not found in session.')
#         else:
#             messages.error(request, 'Form is not valid.')
#     else:
#         form = DoctorForm()
#         doctors = Doctor.objects.all().order_by('-Doctor_ID') 
#     return render(request, 'C-admin/add_doctor.html', {'form': form, 'doctors': doctors})

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib import messages
from customadmin.backend import AdminBackend
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from .form import DoctorForm
from base.models import Doctor, Admin
from django.db import transaction
from django.shortcuts import get_object_or_404
from django.core.exceptions import ObjectDoesNotExist

def custom_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        try:
            user = AdminBackend().authenticate(request, username=username, password=password)

            if user is not None and hasattr(user, 'Admin_ID'):
                request.session['Admin_ID'] = user.Admin_ID
                messages.success(request, f'Welcome, {username}!')
                print("Admin_ID:", request.session.get('Admin_ID'))
                return redirect('dashboard') 
            else:
                messages.error(request, 'Invalid username or password.')
        except Exception as e:
            messages.error(request, f'An error occurred: {str(e)}')

    return render(request, 'C-admin/adlogin.html')

@login_required(login_url='custom_login')
def custom_logout(request):
    if request.user.is_authenticated:
        if 'Admin_ID' in request.session:
            del request.session['Admin_ID']
        logout(request)
        messages.success(request, 'You have been successfully logged out.')
    return redirect('login')

# @login_required(login_url='custom_login')
def add_doctor(request):
    form = DoctorForm()
    doctors = Doctor.objects.all().order_by('-Doctor_ID')
    
    if request.method == 'POST':
        form = DoctorForm(request.POST, request.FILES)
        if form.is_valid():
            admin_id = request.session.get('Admin_ID')
            if admin_id is not None:
                try:
                    with transaction.atomic():
                        doctor = form.save(commit=False)
                        try:
                            admin = Admin.objects.get(pk=admin_id)
                            print(f"Admin found: {admin}")
                            doctor.Admin_ID = admin  
                            doctor.save()
                            messages.success(request, 'Doctor created successfully.')
                            return redirect('add_doctor')
                        except ObjectDoesNotExist:
                            messages.error(request, 'Admin not found.')
                except Exception as e:
                    messages.error(request, f'An error occurred: {str(e)}')
            else:
                messages.error(request, 'Admin ID not found in session.')
        else:
            messages.error(request, 'Form is not valid.')

    return render(request, 'C-admin/add_doctor.html', {'form': form, 'doctors': doctors})

def update_doctor(request, doctor_id):
    doctor = get_object_or_404(Doctor, pk=doctor_id)
    if request.method == 'POST':
        form = DoctorForm(request.POST, request.FILES, instance=doctor)
        if form.is_valid():
            admin_id = request.session.get('Admin_ID')
            if admin_id is not None:
                try:
                    with transaction.atomic():
                        doctor = form.save(commit=False)
                        doctor.Admin_ID_id = admin_id
                        doctor.save()
                    messages.success(request, 'Doctor updated successfully.')
                    return redirect('add_doctor')
                except Exception as e:
                    messages.error(request, f'An error occurred: {str(e)}')
            else:
                messages.error(request, 'Admin ID not found in session.')
        else:
            messages.error(request, 'Form is not valid.')
    else:
        form = DoctorForm(instance=doctor)
        doctors = Doctor.objects.all().order_by('-Doctor_ID') 
    return render(request, 'C-admin/add_doctor.html', {'form': form, 'doctors': doctors})

def delete_doctor(request, doctor_id):
    doctor = get_object_or_404(Doctor, pk=doctor_id)
    if request.method == 'POST':
        try:
            with transaction.atomic():
                doctor.delete()
            messages.success(request, 'Doctor deleted successfully.')
        except Exception as e:
            messages.error(request, f'An error occurred: {str(e)}')
        return redirect('add_doctor')
    return render(request, 'C-admin/delete_doctor_confirmation.html', {'doctor': doctor})

def dashboard(request):
    return render(request, 'C-admin/index.html')

def login(request):
    return render(request, 'C-admin/Adlogin.html')
